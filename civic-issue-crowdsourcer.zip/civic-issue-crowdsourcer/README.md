# CivicFix - Civic Issue Crowdsourcer PWA

A Progressive Web Application for reporting and tracking civic issues in your community.

## Features

- 🗺️ **Interactive Map** - Leaflet.js powered map showing all reported issues
- 📍 **GPS Location** - Automatic location detection using Geolocation API
- 📸 **Camera Integration** - Capture photos directly from mobile devices
- 🔥 **Heatmap Visualization** - Admin dashboard with density heatmaps
- 📌 **Marker Clustering** - Grouped pins for better map readability
- 📱 **PWA Support** - Install on mobile devices, works offline
- 🏷️ **Category Filtering** - Filter issues by type (pothole, lighting, garbage, etc.)
- 🔄 **Status Tracking** - Track reports from pending to resolved

## Tech Stack

- **Frontend**: Next.js 15 (App Router), React, TypeScript, Tailwind CSS
- **Mapping**: Leaflet.js, React-Leaflet, Leaflet.heat, Leaflet.markercluster
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **PWA**: next-pwa with offline support and cache strategies
- **APIs**: Browser Geolocation API, Nominatim (reverse geocoding)

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- A Supabase account and project

### 1. Set Up Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to the SQL Editor and run the schema from `supabase-schema.sql`
3. Create a Storage bucket named `report-images` with public access

### 2. Configure Environment Variables

Copy `.env.local.example` to `.env.local` and fill in your Supabase credentials:

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
civic-issue-crowdsourcer/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── reports/
│   │   │   │   └── route.ts      # Reports API endpoints
│   │   │   └── upload/
│   │   │       └── route.ts      # Image upload endpoint
│   │   ├── admin/
│   │   │   └── page.tsx          # Admin dashboard with heatmap
│   │   ├── report/
│   │   │   └── page.tsx          # Report submission page
│   │   ├── globals.css           # Global styles
│   │   ├── layout.tsx            # Root layout
│   │   └── page.tsx              # Home page with map
│   ├── components/
│   │   ├── ClusteredMap.tsx      # Map with marker clustering
│   │   ├── HeatmapMap.tsx        # Heatmap visualization
│   │   ├── InteractiveMap.tsx    # Main interactive map
│   │   └── ReportForm.tsx        # Report submission form
│   ├── lib/
│   │   └── supabase.ts           # Supabase client
│   └── types/
│       └── index.ts              # TypeScript types
├── public/
│   ├── icons/                    # PWA icons
│   └── manifest.json             # PWA manifest
├── supabase-schema.sql           # Database schema
├── next.config.ts                # Next.js config with PWA
└── package.json
```

## Database Schema

The Supabase schema includes:

- **reports** table with:
  - `id`, `created_at`, `category`, `description`
  - `image_url`, `latitude`, `longitude`, `address`
  - `status` (pending/in_progress/resolved)
  - `user_id`, `location` (PostGIS geography)

- **Indexes** for spatial queries and filtering
- **RLS Policies** for secure access
- **Custom Function** for radius-based queries

## PWA Features

- **Offline Support**: Map tiles and assets are cached
- **Install Prompt**: Can be added to home screen
- **Responsive Design**: Works on all device sizes
- **Camera Access**: Direct camera capture on mobile

## Admin Dashboard

Access the admin dashboard at `/admin`:

- Heatmap visualization of issue density
- Clustered marker view
- Report management (status updates)
- Statistics and analytics

## API Endpoints

### GET /api/reports
Fetch all reports with optional filters:
- `?category=pothole` - Filter by category
- `?status=pending` - Filter by status
- `?lat=40.7&lng=-74.0&radius=1000` - Reports within 1km

### POST /api/reports
Create a new report:
```json
{
  "category": "pothole",
  "description": "Large pothole on Main St",
  "image_url": "https://...",
  "latitude": 40.7128,
  "longitude": -74.0060,
  "address": "123 Main St"
}
```

### POST /api/upload
Upload an image (multipart/form-data):
- Field name: `file`
- Returns: `{ url: "...", path: "..." }`

## Categories

- 🕳️ Pothole
- 💡 Street Lighting
- 🗑️ Garbage/Waste
- 🎨 Graffiti
- 💧 Drainage Issue
- 🛣️ Road Damage
- 📋 Other

## Deployment

### Build for Production

```bash
npm run build
npm start
```

### Deploy to Vercel

1. Push to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy

## License

MIT

## Contributing

Contributions welcome! Please feel free to submit a Pull Request.
