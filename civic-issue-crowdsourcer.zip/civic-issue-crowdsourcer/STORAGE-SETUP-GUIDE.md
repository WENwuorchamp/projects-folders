# Supabase Storage Bucket Setup Guide

## Step 1: Go to Storage
1. Open: https://cddicmxzubwnphkrghkv.supabase.co
2. Click **Storage** in the left sidebar

## Step 2: Create Bucket (if not exists)
1. Click **New bucket**
2. Fill in:
   - **Bucket name**: `report-images`
   - ✅ **Public bucket** (CHECK THIS)
   - File size limit: `5242880` (5MB - optional)
3. Click **Create bucket**

## Step 3: Configure Bucket Policies

After creating the bucket:

1. Click on the `report-images` bucket
2. Click **Policies** tab
3. Click **New policy**
4. Select **Create a policy from scratch**
5. Fill in:

### Policy 1: Public Read Access
```json
{
  "name": "Public Read Access",
  "operation": "SELECT",
  "target": "public"
}
```
- Policy name: `Public Read Access`
- Operation: `SELECT`
- Target role: `public`
- Policy definition (SQL):
```sql
true
```
- Click **Review** then **Save policy**

### Policy 2: Public Upload Access
```json
{
  "name": "Public Upload Access",
  "operation": "INSERT",
  "target": "public"
}
```
- Click **New policy** again
- Policy name: `Public Upload Access`
- Operation: `INSERT`
- Target role: `public`
- Policy definition (SQL):
```sql
true
```
- Click **Review** then **Save policy**

## Step 4: Verify Bucket is Public

1. Go to bucket settings
2. Ensure **Public bucket** toggle is ON (blue)
3. You should see a public URL like:
   `https://cddicmxzubwnphkrghkv.supabase.co/storage/v1/b/report-images`

## Step 5: Test Upload

After setup, test by:
1. Going to http://localhost:3000
2. Click "Report Issue"
3. Take/upload a photo
4. Submit the form

If successful, the image will be stored in your bucket!
