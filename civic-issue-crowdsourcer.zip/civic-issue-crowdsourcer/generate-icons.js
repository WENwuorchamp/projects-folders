const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const outputDir = path.join(__dirname, 'public', 'icons');

// Create SVG content for the icon (blue map pin)
const svgContent = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#2563eb;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#7c3aed;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="100" fill="url(#grad)"/>
  <g fill="white">
    <path d="M256 80c-79.5 0-144 64.5-144 144 0 96 144 240 144 240s144-144 144-240c0-79.5-64.5-144-144-144zm0 192c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48z"/>
    <circle cx="256" cy="224" r="32"/>
  </g>
</svg>
`.trim();

async function generateIcons() {
  console.log('Generating PWA icons...\n');
  
  // Ensure output directory exists
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  // Save SVG
  const svgPath = path.join(outputDir, 'icon.svg');
  fs.writeFileSync(svgPath, svgContent);
  console.log('✓ Created icon.svg');
  
  // Generate PNGs for each size
  for (const size of sizes) {
    const outputPath = path.join(outputDir, `icon-${size}x${size}.png`);
    
    await sharp(Buffer.from(svgContent))
      .resize(size, size)
      .png()
      .toFile(outputPath);
    
    console.log(`✓ Created icon-${size}x${size}.png`);
  }
  
  console.log('\n✅ All icons generated successfully!');
  console.log(`Icons saved to: ${outputDir}`);
}

generateIcons().catch(console.error);
