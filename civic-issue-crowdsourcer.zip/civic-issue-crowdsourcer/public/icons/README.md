# PWA Icons Setup

For production-ready PWA icons, you'll need to generate PNG icons in multiple sizes.

## Quick Setup Options:

### Option 1: Use RealFaviconGenerator (Recommended)
1. Go to https://realfavicongenerator.net/
2. Upload the `icon.svg` file from this directory
3. Download the generated icons
4. Place them in `/public/icons/` with the following names:
   - icon-72x72.png
   - icon-96x96.png
   - icon-128x128.png
   - icon-144x144.png
   - icon-152x152.png
   - icon-192x192.png
   - icon-384x384.png
   - icon-512x512.png

### Option 2: Use Any Online Icon Generator
- https://appicon.co/
- https://icon.kitchen/

### Option 3: Temporary Placeholder
The app will work without icons, but for PWA installation you'll need proper icons.

## Current Icon
The `icon.svg` file contains a simple blue map pin icon that can be used as a base for generating PNG icons.
