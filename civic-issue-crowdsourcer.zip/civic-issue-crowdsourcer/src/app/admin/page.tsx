'use client';

import { useState, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import { BarChart3, Loader2, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { Report, HeatmapPoint } from '@/types';

// Dynamically import map components
const HeatmapMap = dynamic(() => import('@/components/HeatmapMap'), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-slate-100">
      <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
    </div>
  ),
});

const ClusteredMap = dynamic(() => import('@/components/ClusteredMap'), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-slate-100">
      <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
    </div>
  ),
});

export default function AdminPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [heatmapPoints, setHeatmapPoints] = useState<HeatmapPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'heatmap' | 'cluster'>('heatmap');
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
    topCategory: '',
  });

  const fetchReports = useCallback(async () => {
    try {
      const response = await fetch('/api/reports');
      if (!response.ok) throw new Error('Failed to fetch reports');
      const data = await response.json();
      
      const typedReports: Report[] = (data.reports || []).map((r: any) => ({
        ...r,
        latitude: Number(r.latitude),
        longitude: Number(r.longitude),
      }));

      setReports(typedReports);

      // Generate heatmap points with intensity based on clustering
      const points: HeatmapPoint[] = typedReports.map((report) => ({
        lat: report.latitude,
        lng: report.longitude,
        intensity: 1,
      }));
      setHeatmapPoints(points);

      // Calculate stats
      const pending = typedReports.filter(r => r.status === 'pending').length;
      const inProgress = typedReports.filter(r => r.status === 'in_progress').length;
      const resolved = typedReports.filter(r => r.status === 'resolved').length;

      // Find top category
      const categoryCount: Record<string, number> = {};
      typedReports.forEach(r => {
        categoryCount[r.category] = (categoryCount[r.category] || 0) + 1;
      });
      const topCategory = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

      setStats({
        total: typedReports.length,
        pending,
        inProgress,
        resolved,
        topCategory: topCategory.replace('_', ' '),
      });
    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  const updateReportStatus = async (reportId: string, newStatus: Report['status']) => {
    try {
      const response = await fetch(`/api/reports/${reportId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) throw new Error('Failed to update report');

      fetchReports();
    } catch (error) {
      console.error('Error updating report:', error);
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      pothole: 'bg-red-500',
      lighting: 'bg-yellow-500',
      garbage: 'bg-green-500',
      graffiti: 'bg-purple-500',
      drainage: 'bg-blue-500',
      road_damage: 'bg-red-500',
      other: 'bg-gray-500',
    };
    return colors[category] || colors.other;
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-12 h-12 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 shadow-lg border-b border-emerald-700">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
                <p className="text-xs text-emerald-100">Civic Issue Analytics & Management</p>
              </div>
            </div>
            <a
              href="/"
              className="px-4 py-2 text-sm text-white/90 hover:text-white hover:bg-white/20 rounded-lg transition-colors font-medium"
            >
              ← Back to Map
            </a>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-5 h-5 text-slate-500" />
              <span className="text-sm text-slate-500 font-medium">Total</span>
            </div>
            <p className="text-3xl font-bold text-slate-800">{stats.total}</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-yellow-500" />
              <span className="text-sm text-slate-500 font-medium">Pending</span>
            </div>
            <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <span className="text-sm text-slate-500 font-medium">In Progress</span>
            </div>
            <p className="text-3xl font-bold text-blue-600">{stats.inProgress}</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm text-slate-500 font-medium">Resolved</span>
            </div>
            <p className="text-3xl font-bold text-green-600">{stats.resolved}</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              <span className="text-sm text-slate-500 font-medium">Top Category</span>
            </div>
            <p className="text-lg font-bold text-emerald-600 capitalize">{stats.topCategory}</p>
          </div>
        </div>

        {/* Map View Toggle */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 mb-6 overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="text-lg font-semibold text-slate-800">Issue Density Map</h2>
            <div className="flex gap-2">
              <button
                onClick={() => setViewMode('heatmap')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'heatmap'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
              >
                Heatmap
              </button>
              <button
                onClick={() => setViewMode('cluster')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'cluster'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
              >
                Clustered
              </button>
            </div>
          </div>
          <div className="h-[500px] bg-slate-100">
            {viewMode === 'heatmap' ? (
              <HeatmapMap points={heatmapPoints} />
            ) : (
              <ClusteredMap reports={reports} />
            )}
          </div>
        </div>

        {/* Reports Table */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50">
            <h2 className="text-lg font-semibold text-slate-800">All Reports</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Description</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Location</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {reports.map((report) => (
                  <tr
                    key={report.id}
                    className="hover:bg-emerald-50 cursor-pointer transition-colors"
                    onClick={() => setSelectedReport(report)}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${getCategoryColor(report.category)}`} />
                        <span className="capitalize text-sm font-medium text-slate-800">
                          {report.category.replace('_', ' ')}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600 max-w-xs truncate">
                      {report.description || '—'}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600 max-w-xs truncate">
                      {report.address || `${report.latitude.toFixed(4)}, ${report.longitude.toFixed(4)}`}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        report.status === 'resolved'
                          ? 'bg-green-100 text-green-700'
                          : report.status === 'in_progress'
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {report.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-500">
                      {new Date(report.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        {report.status === 'pending' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              updateReportStatus(report.id, 'in_progress');
                            }}
                            className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 font-medium"
                          >
                            Start
                          </button>
                        )}
                        {report.status === 'in_progress' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              updateReportStatus(report.id, 'resolved');
                            }}
                            className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 font-medium"
                          >
                            Resolve
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Report Detail Modal */}
      {selectedReport && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white rounded-t-2xl">
              <h2 className="text-lg font-semibold text-slate-800 capitalize">
                {selectedReport.category.replace('_', ' ')} Report
              </h2>
              <button
                onClick={() => setSelectedReport(null)}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <span className="text-2xl text-slate-500">×</span>
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  selectedReport.status === 'resolved'
                    ? 'bg-green-100 text-green-700'
                    : selectedReport.status === 'in_progress'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-red-100 text-red-700'
                }`}>
                  {selectedReport.status.replace('_', ' ')}
                </span>
                <span className="text-sm text-slate-500">
                  {new Date(selectedReport.created_at).toLocaleString()}
                </span>
              </div>

              {selectedReport.description && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-700 mb-1">Description</h3>
                  <p className="text-slate-600">{selectedReport.description}</p>
                </div>
              )}

              <div>
                <h3 className="text-sm font-semibold text-slate-700 mb-1">Location</h3>
                <p className="text-slate-600">
                  {selectedReport.address || `${selectedReport.latitude.toFixed(6)}, ${selectedReport.longitude.toFixed(6)}`}
                </p>
              </div>

              {selectedReport.image_url && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-700 mb-1">Photo</h3>
                  <img
                    src={selectedReport.image_url}
                    alt="Reported issue"
                    className="w-full h-64 object-cover rounded-xl shadow-md"
                  />
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t border-slate-200">
                {selectedReport.status === 'pending' && (
                  <button
                    onClick={() => {
                      updateReportStatus(selectedReport.id, 'in_progress');
                      setSelectedReport({ ...selectedReport, status: 'in_progress' });
                    }}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-semibold shadow-md"
                  >
                    Mark as In Progress
                  </button>
                )}
                {selectedReport.status === 'in_progress' && (
                  <button
                    onClick={() => {
                      updateReportStatus(selectedReport.id, 'resolved');
                      setSelectedReport({ ...selectedReport, status: 'resolved' });
                    }}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-lg hover:from-green-700 hover:to-green-800 transition-all font-semibold shadow-md"
                  >
                    Mark as Resolved
                  </button>
                )}
                {selectedReport.status === 'resolved' && (
                  <button
                    onClick={() => {
                      updateReportStatus(selectedReport.id, 'pending');
                      setSelectedReport({ ...selectedReport, status: 'pending' });
                    }}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-slate-600 to-slate-700 text-white rounded-lg hover:from-slate-700 hover:to-slate-800 transition-all font-semibold shadow-md"
                  >
                    Reopen Report
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
