'use client';

import { useState, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import { MapPin, Plus, List, BarChart3, Loader2, Filter } from 'lucide-react';
import { Report, Category } from '@/types';

// Dynamically import map components to avoid SSR issues
const InteractiveMap = dynamic(() => import('@/components/InteractiveMap'), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-gray-100">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  ),
});

const CATEGORIES: { value: Category; label: string }[] = [
  { value: 'pothole', label: 'Pothole' },
  { value: 'lighting', label: 'Lighting' },
  { value: 'garbage', label: 'Garbage' },
  { value: 'graffiti', label: 'Graffiti' },
  { value: 'drainage', label: 'Drainage' },
  { value: 'road_damage', label: 'Road Damage' },
  { value: 'other', label: 'Other' },
];

export default function HomePage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [showReportForm, setShowReportForm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  const fetchReports = useCallback(async () => {
    try {
      const response = await fetch('/api/reports');
      if (!response.ok) throw new Error('Failed to fetch reports');
      const data = await response.json();
      setReports(data.reports || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReports();

    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => console.error('Error getting location:', error)
      );
    }
  }, [fetchReports]);

  const filteredReports = selectedCategory === 'all'
    ? reports
    : reports.filter(r => r.category === selectedCategory);

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 shadow-lg border-b border-emerald-700 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">CivicFix</h1>
                <p className="text-xs text-emerald-100">Report & Track Local Issues</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <a
                href="/admin"
                className="p-2 text-white/90 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                title="Admin Dashboard"
              >
                <BarChart3 className="w-5 h-5" />
              </a>
              <button
                onClick={() => setShowReportForm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-white text-emerald-600 rounded-lg hover:bg-emerald-50 transition-colors font-medium shadow-md"
              >
                <Plus className="w-5 h-5" />
                <span className="hidden sm:inline">Report Issue</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Category Filter */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-slate-200 px-4 py-2 overflow-x-auto">
        <div className="flex items-center gap-2 min-w-max">
          <Filter className="w-4 h-4 text-slate-500" />
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-full text-sm whitespace-nowrap transition-colors ${
              selectedCategory === 'all'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-100'
            }`}
          >
            All Issues
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`px-3 py-1 rounded-full text-sm whitespace-nowrap transition-colors ${
                selectedCategory === cat.value
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-emerald-100'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Map */}
        <div className="flex-1 relative">
          {loading ? (
            <div className="h-full w-full flex items-center justify-center bg-gray-100">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : (
            <InteractiveMap
              reports={filteredReports}
              center={userLocation ? [userLocation.lat, userLocation.lng] : [0, 0]}
              zoom={userLocation ? 15 : 13}
            />
          )}

          {/* Stats Overlay */}
          <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-4 z-[1000] border border-emerald-100">
            <div className="text-sm">
              <p className="text-slate-500 font-medium">Total Reports</p>
              <p className="text-3xl font-bold text-emerald-600">{reports.length}</p>
            </div>
            <div className="mt-2 text-sm">
              <p className="text-slate-500 font-medium">Showing</p>
              <p className="font-semibold text-slate-700">{filteredReports.length} issues</p>
            </div>
          </div>
        </div>

        {/* Report List Sidebar (Desktop) */}
        <div className="hidden lg:block w-96 border-l border-slate-200 bg-white overflow-y-auto">
          <div className="p-4">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-slate-800">
              <List className="w-5 h-5 text-emerald-600" />
              Recent Reports
            </h2>
            <div className="space-y-3">
              {filteredReports.slice(0, 10).map((report) => (
                <div
                  key={report.id}
                  className="p-3 border border-slate-200 rounded-xl hover:shadow-md hover:border-emerald-200 transition-all cursor-pointer bg-white"
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-sm font-medium capitalize text-slate-800">
                      {report.category.replace('_', ' ')}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      report.status === 'resolved'
                        ? 'bg-green-100 text-green-700'
                        : report.status === 'in_progress'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {report.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {report.description || 'No description'}
                  </p>
                  <p className="text-xs text-slate-400 mt-2">
                    {new Date(report.created_at).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Report Form Modal */}
      {showReportForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white rounded-t-2xl">
              <h2 className="text-lg font-semibold text-slate-800">Report an Issue</h2>
              <button
                onClick={() => setShowReportForm(false)}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <span className="text-2xl text-slate-500">×</span>
              </button>
            </div>
            <div className="p-4">
              {/* Import ReportForm dynamically to avoid SSR issues */}
              <ReportFormWrapper
                onSuccess={() => {
                  setShowReportForm(false);
                  fetchReports();
                }}
                onCancel={() => setShowReportForm(false)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Wrapper component for ReportForm to handle dynamic import
function ReportFormWrapper({ onSuccess, onCancel }: { onSuccess: () => void; onCancel: () => void }) {
  const ReportForm = dynamic(() => import('@/components/ReportForm'), {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    ),
  });

  return <ReportForm onSuccess={onSuccess} onCancel={onCancel} />;
}
