'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, MapPin, Loader2 } from 'lucide-react';
import dynamic from 'next/dynamic';
import { supabase } from '@/lib/supabase';

const ReportForm = dynamic(() => import('@/components/ReportForm'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  ),
});

export default function ReportPage() {
  const router = useRouter();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number; address?: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          
          // Reverse geocoding
          let address = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
            );
            const data = await response.json();
            address = data.display_name || address;
          } catch (err) {
            console.error('Reverse geocoding error:', err);
          }

          setUserLocation({ latitude, longitude, address });
          setLoading(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setLoading(false);
        }
      );
    } else {
      setLoading(false);
    }
  }, []);

  const handleSuccess = () => {
    // Show success message and redirect
    alert('Report submitted successfully! Thank you for helping improve our community.');
    router.push('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Report an Issue</h1>
            <p className="text-gray-600">
              Help us identify and fix problems in our community. Your reports make a difference!
            </p>
          </div>

          {userLocation && (
            <div className="mb-6 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-blue-900">Your Current Location</p>
                  <p className="text-sm text-blue-700 mt-1">
                    {userLocation.address}
                  </p>
                  <p className="text-xs text-blue-500 mt-1">
                    Coordinates: {userLocation.latitude.toFixed(6)}, {userLocation.longitude.toFixed(6)}
                  </p>
                </div>
              </div>
            </div>
          )}

          <ReportForm
            onSuccess={handleSuccess}
            onCancel={() => router.back()}
            initialLocation={userLocation || undefined}
          />
        </div>

        {/* Info Cards */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl mb-2">📸</div>
            <h3 className="font-medium text-gray-900">1. Take a Photo</h3>
            <p className="text-sm text-gray-600 mt-1">
              Capture clear images of the issue you&apos;re reporting.
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl mb-2">📍</div>
            <h3 className="font-medium text-gray-900">2. Location Auto-Detected</h3>
            <p className="text-sm text-gray-600 mt-1">
              We automatically capture your GPS coordinates.
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl mb-2">✅</div>
            <h3 className="font-medium text-gray-900">3. Submit & Track</h3>
            <p className="text-sm text-gray-600 mt-1">
              Your report will be reviewed and addressed.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
