'use client';

import { useState, useEffect } from 'react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Report } from '@/types';

// Fix for default marker icon in Next.js
if (typeof window !== 'undefined') {
  delete (L.Icon.Default.prototype as any)._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  });
}

// Custom icon for different categories
const getCategoryIcon = (category: string) => {
  const colors: Record<string, string> = {
    pothole: '#ef4444',
    lighting: '#f59e0b',
    garbage: '#22c55e',
    graffiti: '#8b5cf6',
    drainage: '#3b82f6',
    road_damage: '#ef4444',
    other: '#6b7280',
  };

  const color = colors[category] || colors.other;

  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
          <circle cx="12" cy="10" r="3"></circle>
        </svg>
      </div>
    `,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30],
  });
};

interface ClusteredMapProps {
  reports: Report[];
  center?: [number, number];
  zoom?: number;
}

export default function ClusteredMap({ reports, center = [0, 0], zoom = 13 }: ClusteredMapProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-slate-100">
        <p className="text-slate-500">Loading map...</p>
      </div>
    );
  }

  return (
    <MapContainer
      center={center}
      zoom={zoom}
      style={{ height: '100%', width: '100%' }}
      scrollWheelZoom={true}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {reports.map((report) => (
        <Marker
          key={report.id}
          position={[report.latitude, report.longitude]}
          icon={getCategoryIcon(report.category)}
        >
          <Popup>
            <div className="p-2 min-w-[200px]">
              <h3 className="font-bold text-lg capitalize mb-1 text-slate-800">
                {report.category.replace('_', ' ')}
              </h3>
              <p className="text-sm text-slate-600 mb-2">
                {report.description || 'No description'}
              </p>
              {report.address && (
                <p className="text-xs text-slate-500 mb-2">📍 {report.address}</p>
              )}
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  report.status === 'resolved'
                    ? 'bg-green-100 text-green-700'
                    : report.status === 'in_progress'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-red-100 text-red-700'
                }`}>
                  {report.status.replace('_', ' ')}
                </span>
                <span className="text-xs text-slate-500">
                  {new Date(report.created_at).toLocaleDateString()}
                </span>
              </div>
              {report.image_url && (
                <img
                  src={report.image_url}
                  alt="Reported issue"
                  className="mt-2 rounded-lg w-full h-32 object-cover"
                />
              )}
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
