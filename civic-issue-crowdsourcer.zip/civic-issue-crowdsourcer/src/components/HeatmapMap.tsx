'use client';

import { useEffect, useState } from 'react';
import 'leaflet/dist/leaflet.css';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import { HeatmapPoint } from '@/types';

interface SimpleHeatmapMapProps {
  points: HeatmapPoint[];
  center?: [number, number];
  zoom?: number;
}

export default function SimpleHeatmapMap({ points, center = [0, 0], zoom = 13 }: SimpleHeatmapMapProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient || points.length === 0) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-slate-100">
        <p className="text-slate-500">No data points to display</p>
      </div>
    );
  }

  // Calculate heatmap intensity based on point density
  const getHeatColor = (intensity: number) => {
    if (intensity > 0.8) return 'rgba(239, 68, 68, 0.6)'; // Red
    if (intensity > 0.6) return 'rgba(234, 179, 8, 0.6)'; // Yellow
    if (intensity > 0.4) return 'rgba(34, 197, 94, 0.6)'; // Green
    if (intensity > 0.2) return 'rgba(59, 130, 246, 0.6)'; // Blue
    return 'rgba(147, 51, 234, 0.6)'; // Purple
  };

  return (
    <MapContainer
      center={center}
      zoom={zoom}
      style={{ height: '100%', width: '100%' }}
      scrollWheelZoom={true}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {points.map((point, index) => (
        <CircleMarker
          key={index}
          center={[point.lat, point.lng]}
          radius={20 + (point.intensity * 30)}
          fillColor={getHeatColor(point.intensity)}
          fillOpacity={0.6}
          stroke={false}
        >
          <Popup>
            <div className="p-2">
              <p className="font-semibold">Report Location</p>
              <p className="text-sm text-slate-600">
                Lat: {point.lat.toFixed(4)}, Lng: {point.lng.toFixed(4)}
              </p>
              <p className="text-sm text-slate-600">
                Intensity: {(point.intensity * 100).toFixed(0)}%
              </p>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
