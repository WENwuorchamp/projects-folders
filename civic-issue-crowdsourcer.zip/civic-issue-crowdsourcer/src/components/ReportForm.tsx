'use client';

import { useState, useRef, useEffect } from 'react';
import { Camera, MapPin, Upload, X, Loader2 } from 'lucide-react';
import { ReportFormData, Category } from '@/types';

interface ReportFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
  initialLocation?: { latitude: number; longitude: number; address?: string };
}

const CATEGORIES: { value: Category; label: string; icon: string }[] = [
  { value: 'pothole', label: 'Pothole', icon: '🕳️' },
  { value: 'lighting', label: 'Street Lighting', icon: '💡' },
  { value: 'garbage', label: 'Garbage/Waste', icon: '🗑️' },
  { value: 'graffiti', label: 'Graffiti', icon: '🎨' },
  { value: 'drainage', label: 'Drainage Issue', icon: '💧' },
  { value: 'road_damage', label: 'Road Damage', icon: '🛣️' },
  { value: 'other', label: 'Other', icon: '📋' },
];

export default function ReportForm({ onSuccess, onCancel, initialLocation }: ReportFormProps) {
  const [formData, setFormData] = useState<ReportFormData>({
    category: 'other',
    description: '',
    image: null,
    latitude: initialLocation?.latitude || 0,
    longitude: initialLocation?.longitude || 0,
    address: initialLocation?.address,
  });
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locationStatus, setLocationStatus] = useState<'idle' | 'locating' | 'located' | 'error'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Get user's location on mount if not provided
  useEffect(() => {
    if (!initialLocation?.latitude) {
      getUserLocation();
    }
  }, []);

  const getUserLocation = async () => {
    setLocationStatus('locating');
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      setLocationStatus('error');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setFormData(prev => ({ ...prev, latitude, longitude }));
        
        // Reverse geocoding to get address
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();
          setFormData(prev => ({ 
            ...prev, 
            address: data.display_name || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
          }));
        } catch (err) {
          setFormData(prev => ({ 
            ...prev, 
            address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
          }));
        }
        
        setLocationStatus('located');
      },
      (err) => {
        console.error('Error getting location:', err);
        setError('Unable to get your location. Please enable location access.');
        setLocationStatus('error');
      }
    );
  };

  const handleCategorySelect = (category: Category) => {
    setFormData(prev => ({ ...prev, category }));
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size should be less than 5MB');
        return;
      }
      setFormData(prev => ({ ...prev, image: file }));
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.image) {
      setError('Please capture or upload an image');
      return;
    }

    if (formData.latitude === 0 && formData.longitude === 0) {
      setError('Location data is required');
      return;
    }

    setIsSubmitting(true);

    try {
      // Upload image using API
      const uploadFormData = new FormData();
      uploadFormData.append('file', formData.image);

      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: uploadFormData,
      });

      if (!uploadResponse.ok) {
        const uploadError = await uploadResponse.json();
        throw new Error(uploadError.error || 'Failed to upload image');
      }

      const uploadData = await uploadResponse.json();
      const imageUrl = uploadData.url;

      // Create report using API
      const reportResponse = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          category: formData.category,
          description: formData.description,
          image_url: imageUrl,
          latitude: formData.latitude,
          longitude: formData.longitude,
          address: formData.address,
        }),
      });

      if (!reportResponse.ok) {
        const reportError = await reportResponse.json();
        throw new Error(reportError.error || 'Failed to create report');
      }

      onSuccess?.();
    } catch (err: any) {
      console.error('Error submitting report:', err);
      setError(err.message || 'Failed to submit report. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Location Status */}
      <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
        <MapPin className={`w-5 h-5 ${
          locationStatus === 'located' ? 'text-green-600' :
          locationStatus === 'error' ? 'text-red-600' :
          locationStatus === 'locating' ? 'text-yellow-600' : 'text-emerald-600'
        }`} />
        <span className="text-sm text-slate-700 font-medium">
          {locationStatus === 'located' ? '✓ Location captured' :
           locationStatus === 'locating' ? 'Getting your location...' :
           locationStatus === 'error' ? 'Location access denied' : 'Getting your location...'}
        </span>
        {locationStatus !== 'located' && locationStatus !== 'locating' && (
          <button
            type="button"
            onClick={getUserLocation}
            className="ml-auto text-sm text-emerald-600 hover:text-emerald-800 font-medium"
          >
            Retry
          </button>
        )}
      </div>

      {formData.address && (
        <p className="text-sm text-slate-600 font-medium">
          📍 {formData.address}
        </p>
      )}

      {/* Category Selection */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Issue Category
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              type="button"
              onClick={() => handleCategorySelect(cat.value)}
              className={`p-3 rounded-xl border-2 transition-all ${
                formData.category === cat.value
                  ? 'border-emerald-500 bg-emerald-50 shadow-md'
                  : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50'
              }`}
            >
              <span className="text-2xl">{cat.icon}</span>
              <p className="text-sm mt-1 font-medium text-slate-700">{cat.label}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Description (Optional)
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          rows={3}
          className="w-full px-3 py-2 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
          placeholder="Describe the issue in detail..."
        />
      </div>

      {/* Image Upload */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Photo Evidence *
        </label>
        <div className="space-y-3">
          {imagePreview ? (
            <div className="relative">
              <img
                src={imagePreview}
                alt="Preview"
                className="w-full h-48 object-cover rounded-xl shadow-md"
              />
              <button
                type="button"
                onClick={() => {
                  setImagePreview(null);
                  setFormData(prev => ({ ...prev, image: null }));
                  if (fileInputRef.current) fileInputRef.current.value = '';
                }}
                className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors"
            >
              <Camera className="w-12 h-12 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-600 font-medium">
                Tap to capture or upload photo
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Max 5MB
              </p>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageSelect}
            className="hidden"
          />
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-xl">
          <p className="text-sm text-red-600 font-medium">{error}</p>
        </div>
      )}

      {/* Submit Button */}
      <div className="flex gap-3">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-4 py-3 border-2 border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 transition-colors font-medium"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={isSubmitting || !formData.image}
          className="flex-1 px-4 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-semibold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <Upload className="w-5 h-5" />
              Submit Report
            </>
          )}
        </button>
      </div>
    </form>
  );
}
