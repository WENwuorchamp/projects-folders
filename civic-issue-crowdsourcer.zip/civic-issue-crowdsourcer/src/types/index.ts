export interface Report {
  id: string;
  created_at: string;
  category: Category;
  description: string;
  image_url: string;
  latitude: number;
  longitude: number;
  address?: string;
  status: 'pending' | 'in_progress' | 'resolved';
  user_id?: string;
}

export type Category = 
  | 'pothole'
  | 'lighting'
  | 'garbage'
  | 'graffiti'
  | 'drainage'
  | 'road_damage'
  | 'other';

export interface ReportFormData {
  category: Category;
  description: string;
  image: File | null;
  latitude: number;
  longitude: number;
  address?: string;
}

export interface HeatmapPoint {
  lat: number;
  lng: number;
  intensity: number;
}
