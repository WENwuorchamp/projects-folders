-- =====================================================
-- SUPABASE STORAGE BUCKET RLS SETUP
-- Run this in SQL Editor to fix storage access issues
-- =====================================================

-- 1. Create the bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('report-images', 'report-images', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- 2. Drop any existing policies on the bucket (clean slate)
DROP POLICY IF EXISTS "Public Read Access" ON storage.objects;
DROP POLICY IF EXISTS "Public Upload Access" ON storage.objects;
DROP POLICY IF EXISTS "Public Update Access" ON storage.objects;
DROP POLICY IF EXISTS "Public Delete Access" ON storage.objects;

-- 3. Create RLS Policies for the storage.objects table

-- Policy 1: Allow anyone to read/download images (SELECT)
CREATE POLICY "Public Read Access"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'report-images');

-- Policy 2: Allow anyone to upload images (INSERT)
CREATE POLICY "Public Upload Access"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'report-images');

-- Policy 3: Allow anyone to update images (UPDATE)
CREATE POLICY "Public Update Access"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'report-images');

-- Policy 4: Allow anyone to delete images (DELETE)
CREATE POLICY "Public Delete Access"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'report-images');

-- 4. Enable RLS on storage.objects table (if not already enabled)
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- VERIFICATION QUERIES (Run these to check if setup is correct)
-- =====================================================

-- Check if bucket exists and is public
-- SELECT id, name, public FROM storage.buckets WHERE id = 'report-images';

-- Check if policies exist
-- SELECT policyname FROM pg_policies WHERE tablename = 'objects' AND schemaname = 'storage';
