-- Enable PostGIS extension for spatial queries
CREATE EXTENSION IF NOT EXISTS postgis;

-- Create the reports table
CREATE TABLE IF NOT EXISTS reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  category TEXT NOT NULL CHECK (category IN ('pothole', 'lighting', 'garbage', 'graffiti', 'drainage', 'road_damage', 'other')),
  description TEXT,
  image_url TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  address TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'resolved')),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  
  -- Add a geography column for spatial queries
  location GEOGRAPHY(POINT, 4326) GENERATED ALWAYS AS (ST_MakePoint(longitude, latitude)) STORED
);

-- Create index for faster spatial queries
CREATE INDEX IF NOT EXISTS idx_reports_location ON reports USING GIST (location);

-- Create index for category filtering
CREATE INDEX IF NOT EXISTS idx_reports_category ON reports(category);

-- Create index for status filtering
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);

-- Create index for created_at for sorting
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at DESC);

-- Enable Row Level Security
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can read reports
CREATE POLICY "Anyone can read reports"
  ON reports FOR SELECT
  USING (true);

-- Policy: Authenticated users can insert reports
CREATE POLICY "Authenticated users can insert reports"
  ON reports FOR INSERT
  WITH CHECK (auth.role() = 'authenticated' OR auth.role() = 'anon');

-- Policy: Users can update their own reports
CREATE POLICY "Users can update their own reports"
  ON reports FOR UPDATE
  USING (auth.uid() = user_id OR auth.role() = 'service_role');

-- Policy: Service role can delete reports
CREATE POLICY "Service role can delete reports"
  ON reports FOR DELETE
  USING (auth.role() = 'service_role');

-- Create a function to get reports within a radius (in meters)
CREATE OR REPLACE FUNCTION get_reports_within_radius(
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  radius_meters DOUBLE PRECISION
)
RETURNS TABLE (
  id UUID,
  created_at TIMESTAMP WITH TIME ZONE,
  category TEXT,
  description TEXT,
  image_url TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  address TEXT,
  status TEXT,
  distance_meters DOUBLE PRECISION
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    r.id,
    r.created_at,
    r.category,
    r.description,
    r.image_url,
    r.latitude,
    r.longitude,
    r.address,
    r.status,
    ST_Distance(
      r.location::geography,
      ST_MakePoint(lng, lat)::geography
    ) AS distance_meters
  FROM reports r
  WHERE ST_DWithin(
    r.location::geography,
    ST_MakePoint(lng, lat)::geography,
    radius_meters
  );
END;
$$;
